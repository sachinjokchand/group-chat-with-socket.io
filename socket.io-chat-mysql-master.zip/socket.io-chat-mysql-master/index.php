<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   </head>

<body>
<div class="chatBottomAll">
<div class="chatBottom">
<iframe frameborder="0" border="0" cellspacing="0" width="318" height="300" style="border-style: none;position:fixed;bottom:0;right:10px;background:none" scrolling="no" src="http://test.gr:3000/chat.html"></iframe>
</div>
</div>
</body>